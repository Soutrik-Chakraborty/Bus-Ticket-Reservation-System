import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import java.sql.*;
import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class Uregister extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldName;
	private JTextField textFieldSurname;
	private JTextField textFieldUsername;
	private JTextField textFieldMobileNo;
	private JTextField textFieldEmailId;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Uregister frame = new Uregister();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	private JPasswordField passwordField;
	/**
	 * Create the frame.
	 */
	public Uregister() {
		connection=sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 589, 428);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Ulogin ulogin = new Ulogin();
				ulogin.setVisible(true);
			}
		});
		btnBack.setBounds(10, 11, 70, 23);
		contentPane.add(btnBack);
		
		JLabel lblUserRegistration = new JLabel("USER REGISTRATION");
		lblUserRegistration.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblUserRegistration.setHorizontalAlignment(SwingConstants.CENTER);
		lblUserRegistration.setBounds(144, 37, 245, 41);
		contentPane.add(lblUserRegistration);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblName.setHorizontalAlignment(SwingConstants.LEFT);
		lblName.setBounds(96, 106, 106, 28);
		contentPane.add(lblName);
		
		textFieldName = new JTextField();
		textFieldName.setBounds(239, 109, 208, 23);
		contentPane.add(textFieldName);
		textFieldName.setColumns(10);
		
		JLabel lblSurname = new JLabel("Surname:");
		lblSurname.setHorizontalAlignment(SwingConstants.LEFT);
		lblSurname.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblSurname.setBounds(96, 145, 114, 23);
		contentPane.add(lblSurname);
		
		textFieldSurname = new JTextField();
		textFieldSurname.setBounds(239, 143, 208, 23);
		contentPane.add(textFieldSurname);
		textFieldSurname.setColumns(10);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblUsername.setBounds(96, 179, 106, 23);
		contentPane.add(lblUsername);
		
		textFieldUsername = new JTextField();
		textFieldUsername.setBounds(239, 177, 208, 23);
		contentPane.add(textFieldUsername);
		textFieldUsername.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblPassword.setBounds(96, 213, 106, 23);
		contentPane.add(lblPassword);
		
		JLabel lblMobileNo = new JLabel("Mobile No:");
		lblMobileNo.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblMobileNo.setBounds(96, 247, 106, 23);
		contentPane.add(lblMobileNo);
		
		textFieldMobileNo = new JTextField();
		textFieldMobileNo.setBounds(239, 248, 208, 23);
		contentPane.add(textFieldMobileNo);
		textFieldMobileNo.setColumns(10);
		
		JLabel lblEmailId = new JLabel("Email Id:");
		lblEmailId.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblEmailId.setBounds(96, 281, 106, 23);
		contentPane.add(lblEmailId);
		
		textFieldEmailId = new JTextField();
		textFieldEmailId.setBounds(237, 282, 210, 23);
		contentPane.add(textFieldEmailId);
		textFieldEmailId.setColumns(10);
		
		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "insert into User_Details (Name,Surname,Username,Password,MobileNo,EmailId) values (?,?,?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textFieldName.getText());
					pst.setString(2, textFieldSurname.getText());
					pst.setString(3, textFieldUsername.getText());
					pst.setString(4, passwordField.getText());
					pst.setString(5, textFieldMobileNo.getText());
					pst.setString(6, textFieldEmailId.getText());
					pst.execute();
					
					JOptionPane.showMessageDialog(null,"Registered Successfully");
					textFieldName.setText("");
					textFieldSurname.setText("");
					textFieldUsername.setText("");
					passwordField.setText("");
					textFieldMobileNo.setText("");
					textFieldEmailId.setText("");
					
					pst.close();
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		btnSubmit.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnSubmit.setBounds(199, 331, 162, 35);
		contentPane.add(btnSubmit);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(239, 214, 208, 22);
		contentPane.add(passwordField);
	}
}

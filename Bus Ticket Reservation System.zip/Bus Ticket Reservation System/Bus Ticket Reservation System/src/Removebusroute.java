import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import java.awt.Font;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Removebusroute extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Removebusroute frame = new Removebusroute();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	private JTextField textMnt;
	private JTextField textDy;
	private JTextField textAt;
	private JTextField textDt;
	private JTextField textAs;
	private JTextField textBt;
	private JTextField textBn;
	private JTextField textDest;
	private JTextField textSrc;
	private JTextField textBRID;
	private JTextField textYr;
	private JTable table;
	public void refreshTable() {
		try {
			String query = "Select * from Busroute_Details";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	private void jtableLinkDb() {
		try {
			String query = "select * from Busroute_Details ";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			//pst.close();
			//rs.close();
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	/**
	 * Create the frame.
	 */
	public Removebusroute() {
		connection=sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1004, 637);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				ASignIn asignin = new ASignIn();
				asignin.setVisible(true);
			}
		});
		btnBack.setBounds(10, 11, 82, 23);
		contentPane.add(btnBack);
		
		JLabel lblRemoveBusRoute = new JLabel("REMOVE BUS ROUTE");
		lblRemoveBusRoute.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblRemoveBusRoute.setHorizontalAlignment(SwingConstants.CENTER);
		lblRemoveBusRoute.setBounds(360, 24, 262, 46);
		contentPane.add(lblRemoveBusRoute);
		
		JLabel lblBrid = new JLabel("Bus Route ID");
		lblBrid.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblBrid.setBounds(676, 83, 96, 32);
		contentPane.add(lblBrid);
		
		JLabel lblSource = new JLabel("Source");
		lblSource.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblSource.setBounds(676, 119, 100, 32);
		contentPane.add(lblSource);
		
		JLabel lblDestination = new JLabel("Destination");
		lblDestination.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblDestination.setBounds(676, 154, 96, 32);
		contentPane.add(lblDestination);
		
		JLabel lblBusName = new JLabel("Bus Name");
		lblBusName.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblBusName.setBounds(676, 189, 96, 32);
		contentPane.add(lblBusName);
		
		JLabel lblBusType = new JLabel("Bus Type");
		lblBusType.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblBusType.setBounds(676, 227, 115, 32);
		contentPane.add(lblBusType);
		
		JLabel lblAvaliableSeats = new JLabel("Avaliable Seats");
		lblAvaliableSeats.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblAvaliableSeats.setBounds(676, 267, 115, 32);
		contentPane.add(lblAvaliableSeats);
		
		JLabel lblDepartureTime = new JLabel("Departure Time");
		lblDepartureTime.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblDepartureTime.setBounds(676, 302, 115, 32);
		contentPane.add(lblDepartureTime);
		
		JLabel lblArrivalTime = new JLabel("Arrival Time");
		lblArrivalTime.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblArrivalTime.setBounds(676, 332, 115, 32);
		contentPane.add(lblArrivalTime);
		
		JLabel lblDay = new JLabel("Day");
		lblDay.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblDay.setBounds(676, 368, 100, 32);
		contentPane.add(lblDay);
		
		JLabel lblMonth = new JLabel("Month");
		lblMonth.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblMonth.setBounds(676, 403, 96, 32);
		contentPane.add(lblMonth);
		
		textMnt = new JTextField();
		textMnt.setColumns(10);
		textMnt.setBounds(830, 404, 149, 26);
		contentPane.add(textMnt);
		
		textDy = new JTextField();
		textDy.setColumns(10);
		textDy.setBounds(830, 366, 149, 23);
		contentPane.add(textDy);
		
		textAt = new JTextField();
		textAt.setColumns(10);
		textAt.setBounds(830, 332, 149, 23);
		contentPane.add(textAt);
		
		textDt = new JTextField();
		textDt.setColumns(10);
		textDt.setBounds(830, 297, 149, 26);
		contentPane.add(textDt);
		
		textAs = new JTextField();
		textAs.setColumns(10);
		textAs.setBounds(830, 262, 149, 26);
		contentPane.add(textAs);
		
		textBt = new JTextField();
		textBt.setColumns(10);
		textBt.setBounds(830, 225, 149, 26);
		contentPane.add(textBt);
		
		textBn = new JTextField();
		textBn.setColumns(10);
		textBn.setBounds(830, 188, 149, 26);
		contentPane.add(textBn);
		
		textDest = new JTextField();
		textDest.setColumns(10);
		textDest.setBounds(830, 155, 149, 26);
		contentPane.add(textDest);
		
		textSrc = new JTextField();
		textSrc.setColumns(10);
		textSrc.setBounds(830, 117, 149, 23);
		contentPane.add(textSrc);
		
		textBRID = new JTextField();
		textBRID.setColumns(10);
		textBRID.setBounds(830, 83, 149, 23);
		contentPane.add(textBRID);
		
		JButton btnSave = new JButton("SAVE");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "insert into Busroute_Details (BRID,Source,Destin,BusName,BusType,AvailableSeats,DepartureTime,ArrivalTime,Dy,Mnth,Yr) values (?,?,?,?,?,?,?,?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textBRID.getText());
					pst.setString(2, textSrc.getText());
					pst.setString(3, textDest.getText());
					pst.setString(4, textBn.getText());
					pst.setString(5, textBt.getText());
					pst.setString(6, textAs.getText());
					pst.setString(7, textDt.getText());
					pst.setString(8, textAt.getText());
					pst.setString(9, textDy.getText());
					pst.setString(10, textMnt.getText());
					pst.setString(11, textYr.getText());
					
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Saved");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textBRID.setText("");
				textSrc.setText("");
				textDest.setText("");
				textBn.setText("");
				textBt.setText("");
				textAs.setText("");
				textDt.setText("");
				textAt.setText("");
				textDy.setText("");
				textMnt.setText("");
				textYr.setText("");
			}
		});
		btnSave.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnSave.setBounds(743, 489, 165, 32);
		contentPane.add(btnSave);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "Update Busroute_Details set BRID='"+textBRID.getText()+"', Source='"+textSrc.getText()+"',Destin='"+textDest.getText()+"',"
							+ " BusName='"+textBn.getText()+"', BusType='"+textBt.getText()+"',AvailableSeats='"+textAs.getText()+"',"
									+ " DepartureTime='"+textDt.getText()+"',ArrivalTime='"+textAt.getText()+"', Dy='"+textDy.getText()+"', "
									+ "Mnth='"+textMnt.getText()+"', Yr='"+textYr.getText()+"'  where BRID='"+textBRID.getText()+"'";
					PreparedStatement pst = connection.prepareStatement(query);
				
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Updated");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textBRID.setText("");
				textSrc.setText("");
				textDest.setText("");
				textBn.setText("");
				textBt.setText("");
				textAs.setText("");
				textDt.setText("");
				textAt.setText("");
				textDy.setText("");
				textMnt.setText("");
				textYr.setText("");
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnUpdate.setBounds(743, 522, 165, 32);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE ACCOUNT");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int action = JOptionPane.showConfirmDialog(null,"Do you really want to Delete","Delete",JOptionPane.YES_NO_OPTION);
				if(action==0) {
				try {
					String query = "delete from Busroute_Details where BRID='"+textBRID.getText()+"'";
					PreparedStatement pst = connection.prepareStatement(query);
				
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Deleted");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textBRID.setText("");
				textSrc.setText("");
				textDest.setText("");
				textBn.setText("");
				textBt.setText("");
				textAs.setText("");
				textDt.setText("");
				textAt.setText("");
				textDy.setText("");
				textMnt.setText("");
				textYr.setText("");
				}
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnDelete.setBounds(743, 555, 165, 32);
		contentPane.add(btnDelete);
		
		JLabel lblYear = new JLabel("Year");
		lblYear.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblYear.setBounds(676, 441, 96, 32);
		contentPane.add(lblYear);
		
		textYr = new JTextField();
		textYr.setColumns(10);
		textYr.setBounds(830, 442, 149, 26);
		contentPane.add(textYr);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					int row =table.getSelectedRow();
					String BRID = (table.getModel().getValueAt(row, 0)+"");
					String query = "select * from Busroute_Details  where BRID='"+BRID+"' ";
					PreparedStatement pst = connection.prepareStatement(query);
					ResultSet rs =pst.executeQuery();
					
					while(rs.next()) {
						textBRID.setText(rs.getString("BRID"));
						textSrc.setText(rs.getString("Source"));
						textDest.setText(rs.getString("Destin"));
						textBn.setText(rs.getString("BusName"));
						textBt.setText(rs.getString("BusType"));
						textAs.setText(rs.getString("AvailableSeats"));
						textDt.setText(rs.getString("DepartureTime"));
						textAt.setText(rs.getString("ArrivalTime"));
						textDy.setText(rs.getString("Dy"));
						textMnt.setText(rs.getString("Mnth"));
						textYr.setText(rs.getString("Yr"));
						}
					
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		table.setBounds(10, 81, 656, 506);
		contentPane.add(table);
		
		jtableLinkDb();
		//refreshTable();
	}
}

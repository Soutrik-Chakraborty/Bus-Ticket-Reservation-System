import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;

import net.proteanit.sql.DbUtils;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Window.Type;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class TicketBooking extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TicketBooking frame = new TicketBooking();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	/**
	 * Create the frame.
	 */
	public TicketBooking() {
		setFont(new Font("Dialog", Font.BOLD, 10));
		setTitle("Book Ticket");
		connection=sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 454, 570);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				USignIn usignin = new USignIn();
				usignin.setVisible(true);
			}
		});
		btnBack.setBounds(10, 11, 71, 23);
		contentPane.add(btnBack);
		
		JLabel lblBookYourTicket = new JLabel("BOOK YOUR TICKET");
		lblBookYourTicket.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblBookYourTicket.setHorizontalAlignment(SwingConstants.CENTER);
		lblBookYourTicket.setBounds(80, 37, 240, 35);
		contentPane.add(lblBookYourTicket);
		
		JLabel lblSource = new JLabel("SOURCE:");
		lblSource.setFont(new Font("Sitka Text", Font.BOLD, 11));
		lblSource.setHorizontalAlignment(SwingConstants.CENTER);
		lblSource.setBounds(0, 100, 91, 23);
		contentPane.add(lblSource);
		
		JComboBox comboBoxSource = new JComboBox();
		comboBoxSource.setFont(new Font("Tahoma", Font.PLAIN, 13));
		comboBoxSource.setModel(new DefaultComboBoxModel(new String[] {"KOLKATA", "DELHI", "MUMBAI", "CHENNAI"}));
		comboBoxSource.setBounds(173, 100, 178, 23);
		contentPane.add(comboBoxSource);
		
		JLabel lblDestination = new JLabel("DESTINATION:");
		lblDestination.setFont(new Font("Sitka Text", Font.BOLD, 11));
		lblDestination.setHorizontalAlignment(SwingConstants.CENTER);
		lblDestination.setBounds(10, 145, 100, 23);
		contentPane.add(lblDestination);
		
		JComboBox comboBoxDestination = new JComboBox();
		comboBoxDestination.setFont(new Font("Tahoma", Font.PLAIN, 13));
		comboBoxDestination.setModel(new DefaultComboBoxModel(new String[] {"CHENNAI", "DELHI", "MUMBAI", "KOLKATA"}));
		comboBoxDestination.setBounds(172, 144, 179, 23);
		contentPane.add(comboBoxDestination);
		
		JLabel lblDateOfJourney = new JLabel("DATE OF JOURNEY:");
		lblDateOfJourney.setHorizontalAlignment(SwingConstants.CENTER);
		lblDateOfJourney.setFont(new Font("Sitka Text", Font.BOLD, 11));
		lblDateOfJourney.setBounds(20, 195, 105, 23);
		contentPane.add(lblDateOfJourney);
		
		JLabel lblNewLabel = new JLabel("DAY");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(155, 198, 33, 14);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBoxDay = new JComboBox();
		comboBoxDay.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBoxDay.setBounds(184, 194, 40, 23);
		contentPane.add(comboBoxDay);
		
		JLabel lblMonth = new JLabel("MONTH");
		lblMonth.setHorizontalAlignment(SwingConstants.CENTER);
		lblMonth.setBounds(234, 198, 53, 14);
		contentPane.add(lblMonth);
		
		JComboBox comboBoxMonth = new JComboBox();
		comboBoxMonth.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		comboBoxMonth.setBounds(280, 194, 40, 23);
		contentPane.add(comboBoxMonth);
		
		JLabel lblYear = new JLabel("YEAR");
		lblYear.setHorizontalAlignment(SwingConstants.CENTER);
		lblYear.setBounds(330, 198, 33, 14);
		contentPane.add(lblYear);
		
		JComboBox comboBoxYear = new JComboBox();
		comboBoxYear.setModel(new DefaultComboBoxModel(new String[] {"2018"}));
		comboBoxYear.setBounds(360, 193, 53, 24);
		contentPane.add(comboBoxYear);
		
		JLabel lblNewLabel_1 = new JLabel("CHOOSE BUS TYPE:");
		lblNewLabel_1.setFont(new Font("Sitka Text", Font.BOLD, 11));
		lblNewLabel_1.setBounds(20, 241, 115, 23);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBoxBusType = new JComboBox();
		comboBoxBusType.setModel(new DefaultComboBoxModel(new String[] {"AC", "NON-AC"}));
		comboBoxBusType.setBounds(165, 240, 65, 23);
		contentPane.add(comboBoxBusType);
		
		JButton btnSearch = new JButton("SEARCH");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "select * from Busroute_Details  where Source = ? and Destin = ? and BusType = ? and Dy = ? and Mnth = ? and Yr = ?  ";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, comboBoxSource.getSelectedItem()+"");
					pst.setString(2, comboBoxDestination.getSelectedItem()+"");
					pst.setString(3, comboBoxBusType.getSelectedItem()+"");
					pst.setString(4, comboBoxDay.getSelectedItem()+"");
					pst.setString(5, comboBoxMonth.getSelectedItem()+"");
					pst.setString(6, comboBoxYear.getSelectedItem()+"");
					//JOptionPane.showMessageDialog(null, query);
					ResultSet rs =pst.executeQuery();
					
					table.setModel(DbUtils.resultSetToTableModel(rs));
					/*while(rs.next()) {
					
					}*/
					
					
					pst.close();
					rs.close();
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnSearch.setFont(new Font("Sitka Text", Font.BOLD, 12));
		btnSearch.setBounds(113, 286, 190, 35);
		contentPane.add(btnSearch);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				JOptionPane.showMessageDialog(null, "Ticket Booked");
				
				/*try {
					int index =table.getSelectedRow();
			        TableModel model=table.getModel();
			        String source=(String) model.getValueAt(index, 0);
			        String dest=(String) model.getValueAt(index, 1);
			        String =(String) model.getValueAt(index, 2);
			        String time=(String) model.getValueAt(index, 3);
			        String price=(String) model.getValueAt(index, 4);
			        String avail_seat=(String) model.getValueAt(index, 5);
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}*/

			}
		});
		table.setBounds(0, 364, 438, 156);
		contentPane.add(table);
		
		JLabel lblSearchResult = new JLabel("Search Result......");
		lblSearchResult.setFont(new Font("Trebuchet MS", Font.PLAIN, 14));
		lblSearchResult.setHorizontalAlignment(SwingConstants.LEFT);
		lblSearchResult.setBounds(10, 325, 125, 28);
		contentPane.add(lblSearchResult);
	}
}

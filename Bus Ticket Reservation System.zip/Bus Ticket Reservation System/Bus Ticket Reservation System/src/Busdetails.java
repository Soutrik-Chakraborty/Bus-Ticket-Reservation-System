import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTable;

public class Busdetails extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Busdetails frame = new Busdetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Busdetails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 543, 359);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBusDetails = new JLabel("BUS DETAILS");
		lblBusDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblBusDetails.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblBusDetails.setBounds(156, 21, 180, 48);
		contentPane.add(lblBusDetails);
		
		JButton button = new JButton("BACK");
		button.setBounds(10, 4, 59, 23);
		contentPane.add(button);
		
		table = new JTable();
		table.setBounds(10, 68, 326, 241);
		contentPane.add(table);
		
		JButton button_1 = new JButton("SAVE");
		button_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		button_1.setBounds(357, 211, 141, 32);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("UPDATE");
		button_2.setFont(new Font("Times New Roman", Font.BOLD, 12));
		button_2.setBounds(357, 244, 141, 32);
		contentPane.add(button_2);
		
		JButton btnDelete = new JButton("DELETE ");
		btnDelete.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnDelete.setBounds(357, 277, 141, 32);
		contentPane.add(btnDelete);
	}
}

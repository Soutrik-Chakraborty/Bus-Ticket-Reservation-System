import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Welcome {

	public JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Welcome window = new Welcome();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the application.
	 */
	public Welcome() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 735, 446);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblBusTicketReservation = new JLabel("Bus Ticket Reservation System");
		lblBusTicketReservation.setHorizontalAlignment(SwingConstants.CENTER);
		lblBusTicketReservation.setFont(new Font("Verdana", Font.BOLD, 24));
		lblBusTicketReservation.setBounds(135, 11, 424, 62);
		frame.getContentPane().add(lblBusTicketReservation);
		
		JButton btnUser = new JButton("USER");
		btnUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				Ulogin ulogin = new Ulogin();
				ulogin.setVisible(true);
			}
		});
		btnUser.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnUser.setBounds(516, 168, 102, 39);
		frame.getContentPane().add(btnUser);
		
		JButton btnAdmin = new JButton("ADMIN");
		btnAdmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				ALogin alogin = new ALogin();
				alogin.setVisible(true);
			}
		});
		btnAdmin.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnAdmin.setBounds(516, 268, 102, 39);
		frame.getContentPane().add(btnAdmin);
		
		JLabel lblBusImage = new JLabel("");
		lblBusImage.setHorizontalAlignment(SwingConstants.CENTER);
		Image img = new ImageIcon(this.getClass().getResource("/bus-icon.png")).getImage();
		lblBusImage.setIcon(new ImageIcon(img));
		lblBusImage.setBounds(20, 61, 454, 334);
		frame.getContentPane().add(lblBusImage);
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
	}
}

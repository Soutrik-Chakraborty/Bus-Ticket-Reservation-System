import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ASignIn extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ASignIn frame = new ASignIn();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ASignIn() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 659, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblWecomeAdmin = new JLabel("Welcome: ADMIN");
		lblWecomeAdmin.setFont(new Font("Sitka Text", Font.PLAIN, 18));
		lblWecomeAdmin.setHorizontalAlignment(SwingConstants.CENTER);
		lblWecomeAdmin.setBounds(427, 27, 192, 42);
		contentPane.add(lblWecomeAdmin);
		
		JButton btnCustomerDetails = new JButton("USER DETAILS");
		btnCustomerDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				CDetails frame = new CDetails();
			    frame.setVisible(true);
			}
		});
		btnCustomerDetails.setBounds(42, 117, 235, 48);
		contentPane.add(btnCustomerDetails);
		
		JButton btnAddBusRoute = new JButton("BUS ROUTE");
		btnAddBusRoute.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Addbusroute frame = new Addbusroute();
			    frame.setVisible(true);
			}
		});
		btnAddBusRoute.setBounds(362, 117, 257, 48);
		contentPane.add(btnAddBusRoute);
		
		JButton btnLogOut = new JButton("LOG OUT");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				JOptionPane.showMessageDialog(null, "Logout Successfully");
				ALogin alogin = new ALogin();
				alogin.setVisible(true);
			}
		});
		btnLogOut.setBounds(197, 294, 257, 52);
		contentPane.add(btnLogOut);
		
		JButton btnAdminDetails = new JButton("ADMIN DETAILS");
		btnAdminDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Adetails frame = new Adetails();
			    frame.setVisible(true);
			}
		});
		btnAdminDetails.setBounds(366, 206, 253, 52);
		contentPane.add(btnAdminDetails);
		
		JButton btnBookingDetails = new JButton("BOOKING DETAILS");
		btnBookingDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				BookDetails frame = new BookDetails();
			    frame.setVisible(true);
			}
		});
		btnBookingDetails.setBounds(42, 206, 235, 52);
		contentPane.add(btnBookingDetails);
	}
}

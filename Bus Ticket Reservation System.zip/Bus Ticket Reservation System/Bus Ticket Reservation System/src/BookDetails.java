import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.sql.*;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class BookDetails extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookDetails frame = new BookDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	private JTextField textTktNo;
	private JTextField textUsername;
	private JTextField textSource;
	private JTextField textDestination;
	private JTextField textBt;
	private JTextField textDt;
	private JTextField textSn;
	private JTextField textDoj;
	private JTextField textTf;
	public void refreshTable() {
		try {
			String query = "Select * from Booking_Details";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	private void jtableLinkDb() {
		try {
			String query = "select * from Booking_Details ";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			//pst.close();
			//rs.close();
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	/**
	 * Create the frame.
	 */
	public BookDetails() {
		connection=sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1005, 571);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JOptionPane.showMessageDialog(null, "Do not intefere with the Ticket No!!");
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				ASignIn asignin = new ASignIn();
				asignin.setVisible(true);
			}
		});
		btnNewButton.setBounds(10, 11, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblBookingDetails = new JLabel("BOOKING DETAILS");
		lblBookingDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblBookingDetails.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblBookingDetails.setBounds(345, 23, 239, 37);
		contentPane.add(lblBookingDetails);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					int row =table.getSelectedRow();
					String TktNo = (table.getModel().getValueAt(row, 0)+"");
					String query = "select * from Booking_Details  where TicketNo='"+TktNo+"' ";
					PreparedStatement pst = connection.prepareStatement(query);
					ResultSet rs =pst.executeQuery();
					
					while(rs.next()) {
						textTktNo.setText(rs.getString("TicketNo"));
						textUsername.setText(rs.getString("Username"));
						textSource.setText(rs.getString("Source"));
						textDestination.setText(rs.getString("Destin"));
						textBt.setText(rs.getString("BoardingTime"));
						textDt.setText(rs.getString("DepartureTime"));
						textSn.setText(rs.getString("SeatNumber"));
						textDoj.setText(rs.getString("DateOfJourney"));
						//textLoc.setText(rs.getString("Location"));
						textTf.setText(rs.getString("TotalFare"));
						}
					
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		table.setBounds(10, 64, 656, 461);
		contentPane.add(table);
		
		JLabel lblSeatNumber = new JLabel("Seat Number");
		lblSeatNumber.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblSeatNumber.setBounds(676, 283, 96, 32);
		contentPane.add(lblSeatNumber);
		
		JLabel lblDepartureTime = new JLabel("Departure Time");
		lblDepartureTime.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblDepartureTime.setBounds(676, 248, 115, 32);
		contentPane.add(lblDepartureTime);
		
		JLabel lblBoardingTime = new JLabel("Boarding Time");
		lblBoardingTime.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblBoardingTime.setBounds(676, 208, 115, 32);
		contentPane.add(lblBoardingTime);
		
		JLabel lblDestination = new JLabel("Destination");
		lblDestination.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblDestination.setBounds(676, 170, 96, 32);
		contentPane.add(lblDestination);
		
		JLabel lblSource = new JLabel("Source");
		lblSource.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblSource.setBounds(676, 135, 96, 32);
		contentPane.add(lblSource);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblUsername.setBounds(676, 100, 100, 32);
		contentPane.add(lblUsername);
		
		JLabel lblTicketNo = new JLabel("Ticket No");
		lblTicketNo.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblTicketNo.setBounds(676, 64, 96, 32);
		contentPane.add(lblTicketNo);
		
		JLabel lblDateOfJourney = new JLabel("Date Of Journey");
		lblDateOfJourney.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblDateOfJourney.setBounds(676, 313, 115, 32);
		contentPane.add(lblDateOfJourney);
		
		JLabel lblTotalFare = new JLabel("Total Fare");
		lblTotalFare.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblTotalFare.setBounds(676, 353, 96, 32);
		contentPane.add(lblTotalFare);
		
		textTktNo = new JTextField();
		textTktNo.setColumns(10);
		textTktNo.setBounds(830, 64, 149, 23);
		contentPane.add(textTktNo);
		
		textUsername = new JTextField();
		textUsername.setColumns(10);
		textUsername.setBounds(830, 98, 149, 23);
		contentPane.add(textUsername);
		
		textSource = new JTextField();
		textSource.setColumns(10);
		textSource.setBounds(830, 136, 149, 26);
		contentPane.add(textSource);
		
		textDestination = new JTextField();
		textDestination.setColumns(10);
		textDestination.setBounds(830, 169, 149, 26);
		contentPane.add(textDestination);
		
		textBt = new JTextField();
		textBt.setColumns(10);
		textBt.setBounds(830, 206, 149, 26);
		contentPane.add(textBt);
		
		textDt = new JTextField();
		textDt.setColumns(10);
		textDt.setBounds(830, 243, 149, 26);
		contentPane.add(textDt);
		
		textSn = new JTextField();
		textSn.setColumns(10);
		textSn.setBounds(830, 278, 149, 26);
		contentPane.add(textSn);
		
		textDoj = new JTextField();
		textDoj.setColumns(10);
		textDoj.setBounds(830, 313, 149, 23);
		contentPane.add(textDoj);
		
		textTf = new JTextField();
		textTf.setColumns(10);
		textTf.setBounds(830, 356, 149, 26);
		contentPane.add(textTf);
		
		JButton button = new JButton("SAVE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "insert into Booking_Details (TicketNo,Username,Source,Destin,BoardingTime,DepartureTime,SeatNumber,DateOfJourney,TotalFare) values (?,?,?,?,?,?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textTktNo.getText());
					pst.setString(2, textUsername.getText());
					pst.setString(3, textSource.getText());
					pst.setString(4, textDestination.getText());
					pst.setString(5, textBt.getText());
					pst.setString(6, textDt.getText());
					pst.setString(7, textSn.getText());
					pst.setString(8, textDoj.getText());
					pst.setString(9, textTf.getText());
					
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Saved");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textTktNo.setText("");
				textUsername.setText("");
				textSource.setText("");
				textDestination.setText("");
				textBt.setText("");
				textDt.setText("");
				textSn.setText("");
				textDoj.setText("");
				textTf.setText("");
			}
		});
		button.setFont(new Font("Times New Roman", Font.BOLD, 12));
		button.setBounds(740, 409, 165, 32);
		contentPane.add(button);
		
		JButton button_1 = new JButton("UPDATE");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "Update Booking_Details set TicketNo='"+textTktNo.getText()+"', Username='"+textUsername.getText()+"',Source='"+textSource.getText()+"', Destin='"+textDestination.getText()+"', BoardingTime='"+textBt.getText()+"', DepartureTime='"+textDt.getText()+"', SeatNumber='"+textSn.getText()+"', DateOfJourney='"+textDoj.getText()+"', TotalFare='"+textTf.getText()+"' where TicketNo='"+textTktNo.getText()+"'";
					PreparedStatement pst = connection.prepareStatement(query);
				
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Updated");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textTktNo.setText("");
				textUsername.setText("");
				textSource.setText("");
				textDestination.setText("");
				textBt.setText("");
				textDt.setText("");
				textSn.setText("");
				textDoj.setText("");
				textTf.setText("");
			}
		});
		button_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		button_1.setBounds(740, 442, 165, 32);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("DELETE ACCOUNT");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int action = JOptionPane.showConfirmDialog(null,"Do you really want to Delete","Delete",JOptionPane.YES_NO_OPTION);
				if(action==0) {
				try {
					String query = "delete from Booking_Details where TicketNo='"+textTktNo.getText()+"'";
					PreparedStatement pst = connection.prepareStatement(query);
				
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Deleted");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textTktNo.setText("");
				textUsername.setText("");
				textSource.setText("");
				textDestination.setText("");
				textBt.setText("");
				textDt.setText("");
				textSn.setText("");
				textDoj.setText("");
				textTf.setText("");
			}
		}
	});
		button_2.setFont(new Font("Times New Roman", Font.BOLD, 12));
		button_2.setBounds(740, 475, 165, 32);
		contentPane.add(button_2);
		
		jtableLinkDb();
		refreshTable();

	}
}

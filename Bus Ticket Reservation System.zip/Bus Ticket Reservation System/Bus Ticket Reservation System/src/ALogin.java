import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ALogin extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldAu;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ALogin frame = new ALogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	private JPasswordField passwordField;
	/**
	 * Create the frame.
	 */
	public ALogin() {
		connection=sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 640, 405);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAdmin = new JLabel("ADMIN LOGIN");
		lblAdmin.setFont(new Font("Sitka Text", Font.BOLD, 24));
		lblAdmin.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdmin.setBounds(231, 45, 190, 36);
		contentPane.add(lblAdmin);
		
		JLabel label = new JLabel("USERNAME");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		label.setBounds(179, 123, 99, 36);
		contentPane.add(label);
		
		textFieldAu = new JTextField();
		textFieldAu.setColumns(10);
		textFieldAu.setBounds(329, 123, 142, 36);
		contentPane.add(textFieldAu);
		
		JLabel label_1 = new JLabel("PASSWORD");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		label_1.setBounds(179, 181, 100, 36);
		contentPane.add(label_1);
		
		JButton btnLogIn = new JButton("LOG IN");
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "select * from Admin_Details where username = ? and password = ?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textFieldAu.getText());
					pst.setString(2, passwordField.getText());
					
					ResultSet rs = pst.executeQuery();
					int count=0;
					while(rs.next()) {
						count++;
					}
					if(count==1) {
						JOptionPane.showMessageDialog(null, "Login Successfully");
						dispose();
						ASignIn asignin = new ASignIn();
						asignin.setVisible(true);
					}
					else if(count > 1) {
						JOptionPane.showMessageDialog(null, "Duplicate Username and Password");
					}
					else {
						JOptionPane.showMessageDialog(null, "Username and Password is not correct Try Again....");
					}
					rs.close();
					pst.close();
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e);
				}
			}
		});
		btnLogIn.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnLogIn.setBounds(200, 261, 99, 36);
		contentPane.add(btnLogIn);
		
		JButton button_1 = new JButton("BACK");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Welcome wlcm = new Welcome();
			    wlcm.frame.setVisible(true);
			}
		});
		button_1.setBounds(10, 11, 70, 23);
		contentPane.add(button_1);
		
		JButton btnNewButton = new JButton("RESET");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldAu.setText("");
				passwordField.setText("");
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnNewButton.setBounds(357, 261, 99, 36);
		contentPane.add(btnNewButton);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(329, 181, 142, 36);
		contentPane.add(passwordField);
	}
}

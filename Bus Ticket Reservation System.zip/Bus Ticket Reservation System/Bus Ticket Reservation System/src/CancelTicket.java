import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.*;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import net.proteanit.sql.DbUtils;

public class CancelTicket extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CancelTicket frame = new CancelTicket();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	private JTable table;
	
	public void refreshTable() {
		try {
			String query = "Select TicketNo,Source,Destin,BoardingTime,DepartureTime,SeatNumber,DateOfJourney,TotalFare from Booking_Details";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			pst.close();
			rs.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	private void jtableLinkDb() {
		try {
			String query = "select TicketNo,Source,Destin,BoardingTime,DepartureTime,SeatNumber,DateOfJourney,TotalFare from Booking_Details ";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			//pst.close();
			//rs.close();
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	/**
	 * Create the frame.
	 */
	public CancelTicket() {
		connection = sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 627, 395);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCancelYourTicket = new JLabel("CANCEL YOUR TICKET");
		lblCancelYourTicket.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblCancelYourTicket.setBounds(196, 31, 238, 38);
		contentPane.add(lblCancelYourTicket);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				USignIn usignin = new USignIn();
				usignin.setVisible(true);
			}
		});
		btnBack.setBounds(10, 11, 68, 23);
		contentPane.add(btnBack);
		
		JButton btnCancelTicket = new JButton("CANCEL TICKET");
		btnCancelTicket.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				int action = JOptionPane.showConfirmDialog(null,"Do you really want to Delete","Delete",JOptionPane.YES_NO_OPTION);
				if(action==0) {
					try {
						int row = table.getSelectedRow();
						String src = (table.getModel().getValueAt(row,0)+"");
						String query = "delete from Booking_Details where TicketNo='"+src+"'";
						PreparedStatement pst = connection.prepareStatement(query);
						model.removeRow(row);
						pst.execute();
						
						JOptionPane.showMessageDialog(null, "Ticket Canceled");
						
						pst.close();
						
					}catch(Exception ex) {
						ex.printStackTrace();
					}
					refreshTable();
					}
				/*int action = JOptionPane.showConfirmDialog(null,"Do you really want to Delete","Delete",JOptionPane.YES_NO_OPTION);
				if(action==0) {
				try {
					int row = table.getSelectedRow();
					model.removeRow(row);	
					JOptionPane.showMessageDialog(null, "Ticket Canceled");
				}catch(Exception ex) {
					ex.printStackTrace();
				}*/
			  }
						
		});
		btnCancelTicket.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnCancelTicket.setBounds(246, 322, 150, 34);
		contentPane.add(btnCancelTicket);
		
		table = new JTable();
		table.setBounds(10, 74, 591, 237);
		contentPane.add(table);
		
		jtableLinkDb();
		//refreshTable();
	}
}

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import javax.swing.*;

public class CDetails extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CDetails frame = new CDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	private JTextField textUID;
	private JTextField textName;
	private JTextField textSurname;
	private JTextField textUsername;
	private JTextField textPassword;
	private JTextField textMobileNo;
	private JTextField textEmailId;
	public void refreshTable() {
		try {
			String query = "Select * from User_Details";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	private void jtableLinkDb() {
		try {
			String query = "select * from User_Details ";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			//pst.close();
			//rs.close();
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	/**
	 * Create the frame.
	 */
	public CDetails() {
		connection=sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 473);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JOptionPane.showMessageDialog(null, "Do not interfere with the Admin Id!!");
		
		JLabel lblCustomerDetails = new JLabel("CUSTOMER DETAILS");
		lblCustomerDetails.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblCustomerDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblCustomerDetails.setBounds(297, 21, 229, 47);
		contentPane.add(lblCustomerDetails);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					int row =table.getSelectedRow();
					String UID = (table.getModel().getValueAt(row, 0)+"");
					String query = "select * from User_Details  where UID='"+UID+"' ";
					PreparedStatement pst = connection.prepareStatement(query);
					ResultSet rs =pst.executeQuery();
					
					while(rs.next()) {
						textUID.setText(rs.getString("UID"));
						textName.setText(rs.getString("Name"));
						textSurname.setText(rs.getString("Surname"));
						textUsername.setText(rs.getString("Username"));
						textPassword.setText(rs.getString("Password"));
						textMobileNo.setText(rs.getString("MobileNo"));
						textEmailId.setText(rs.getString("EmailId"));
					}
					
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		table.setBounds(10, 71, 553, 357);
		contentPane.add(table);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				ASignIn asignin = new ASignIn();
				asignin.setVisible(true);
			}
		});
		btnBack.setBounds(20, 3, 72, 23);
		contentPane.add(btnBack);
		
		textUID = new JTextField();
		textUID.setColumns(10);
		textUID.setBounds(696, 85, 149, 23);
		contentPane.add(textUID);
		
		textName = new JTextField();
		textName.setColumns(10);
		textName.setBounds(696, 119, 149, 23);
		contentPane.add(textName);
		
		textSurname = new JTextField();
		textSurname.setColumns(10);
		textSurname.setBounds(696, 157, 149, 26);
		contentPane.add(textSurname);
		
		textUsername = new JTextField();
		textUsername.setColumns(10);
		textUsername.setBounds(696, 190, 149, 26);
		contentPane.add(textUsername);
		
		textPassword = new JTextField();
		textPassword.setColumns(10);
		textPassword.setBounds(696, 227, 149, 26);
		contentPane.add(textPassword);
		
		textMobileNo = new JTextField();
		textMobileNo.setColumns(10);
		textMobileNo.setBounds(696, 264, 149, 26);
		contentPane.add(textMobileNo);
		
		textEmailId = new JTextField();
		textEmailId.setColumns(10);
		textEmailId.setBounds(696, 299, 149, 26);
		contentPane.add(textEmailId);
		
		JLabel label = new JLabel("User Id");
		label.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label.setBounds(586, 80, 96, 32);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Name");
		label_1.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label_1.setBounds(586, 116, 100, 32);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("Surname");
		label_2.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label_2.setBounds(586, 151, 96, 32);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("Username");
		label_3.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label_3.setBounds(586, 186, 96, 32);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("Password");
		label_4.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label_4.setBounds(586, 224, 96, 32);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("Mobile No");
		label_5.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label_5.setBounds(586, 264, 96, 32);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("Email Id");
		label_6.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label_6.setBounds(586, 299, 96, 32);
		contentPane.add(label_6);
		
		JButton btnSave = new JButton("SAVE");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "insert into User_Details (UID,Name,Surname,Username,Password,MobileNo,EmailId) values (?,?,?,?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textUID.getText());
					pst.setString(2, textName.getText());
					pst.setString(3, textSurname.getText());
					pst.setString(4, textUsername.getText());
					pst.setString(5, textPassword.getText());
					pst.setString(6, textMobileNo.getText());
					pst.setString(7, textEmailId.getText());
					
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Saved");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textUID.setText("");
				textName.setText("");
				textSurname.setText("");
				textUsername.setText("");
				textPassword.setText("");
				textMobileNo.setText("");
				textEmailId.setText("");
			}
		});
		btnSave.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnSave.setBounds(625, 330, 165, 32);
		contentPane.add(btnSave);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//JOptionPane.showMessageDialog(null, "Do not interfere with the User Id!!");
				try {
					String query = "Update User_Details set UID='"+textUID.getText()+"', Name='"+textName.getText()+"',Surname='"+textSurname.getText()+"', Username='"+textUsername.getText()+"', Password='"+textPassword.getText()+"', MobileNo='"+textMobileNo.getText()+"', EmailId='"+textEmailId.getText()+"' where UID='"+textUID.getText()+"'";
					PreparedStatement pst = connection.prepareStatement(query);
				
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Updated");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textUID.setText("");
				textName.setText("");
				textSurname.setText("");
				textUsername.setText("");
				textPassword.setText("");
				textMobileNo.setText("");
				textEmailId.setText("");
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnUpdate.setBounds(625, 363, 165, 32);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE ACCOUNT");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int action = JOptionPane.showConfirmDialog(null,"Do you really want to Delete","Delete",JOptionPane.YES_NO_OPTION);
				if(action==0) {
				try {
					String query = "delete from User_Details where UID='"+textUID.getText()+"'";
					PreparedStatement pst = connection.prepareStatement(query);
				
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Deleted");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textUID.setText("");
				textName.setText("");
				textSurname.setText("");
				textUsername.setText("");
				textPassword.setText("");
				textMobileNo.setText("");
				textEmailId.setText("");
				}
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnDelete.setBounds(625, 396, 165, 32);
		contentPane.add(btnDelete);
		
		jtableLinkDb();
		refreshTable();
	}
}

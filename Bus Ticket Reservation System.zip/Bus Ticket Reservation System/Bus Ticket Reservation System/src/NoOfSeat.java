import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;

public class NoOfSeat extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NoOfSeat frame = new NoOfSeat();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NoOfSeat() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 415, 252);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnOk = new JButton("OK");
		btnOk.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnOk.setBounds(127, 153, 113, 34);
		contentPane.add(btnOk);
		
		textField = new JTextField();
		textField.setBounds(187, 74, 165, 40);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblEnterNoOf = new JLabel("NO OF SEATS:");
		lblEnterNoOf.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblEnterNoOf.setBounds(10, 74, 151, 40);
		contentPane.add(lblEnterNoOf);
	}
}

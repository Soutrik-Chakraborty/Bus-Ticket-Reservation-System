import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;

public class USignIn extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					USignIn frame = new USignIn();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public USignIn() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 724, 454);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome: USER");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Sitka Text", Font.PLAIN, 20));
		lblNewLabel.setBounds(479, 32, 189, 50);
		contentPane.add(lblNewLabel);
		
		JButton btnNewBooking = new JButton("BOOK TICKET");
		btnNewBooking.setFont(new Font("Sitka Text", Font.ITALIC, 15));
		btnNewBooking.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				TicketBooking tktbook = new TicketBooking();
				tktbook.setVisible(true);
			}
		});
		btnNewBooking.setBounds(119, 160, 180, 50);
		contentPane.add(btnNewBooking);
		
		JButton btnMyBooking = new JButton("CANCEL TICKET");
		btnMyBooking.setFont(new Font("Sitka Text", Font.ITALIC, 15));
		btnMyBooking.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				CancelTicket canltkt = new CancelTicket();
				canltkt.setVisible(true);
			}
		});
		btnMyBooking.setBounds(422, 160, 160, 50);
		contentPane.add(btnMyBooking);
		
		JButton btnSignOut = new JButton("LOG OUT");
		btnSignOut.setFont(new Font("Verdana", Font.BOLD, 15));
		btnSignOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				JOptionPane.showMessageDialog(null, "Logout Successfully");
				Ulogin ulogin = new Ulogin();
				ulogin.setVisible(true);
			}
		});
		btnSignOut.setBounds(282, 277, 166, 50);
		contentPane.add(btnSignOut);
	}
}

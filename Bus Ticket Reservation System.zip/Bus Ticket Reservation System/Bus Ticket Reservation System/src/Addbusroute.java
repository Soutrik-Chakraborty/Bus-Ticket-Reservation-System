import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.*;

public class Addbusroute extends JFrame {

	private JPanel contentPane;
	private JTextField textBn;
	private JTextField textAs;
	private JTextField textDt;
	private JTextField textAt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Addbusroute frame = new Addbusroute();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	/**
	 * Create the frame.
	 */
	public Addbusroute() {
		connection=sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 672, 489);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAddNewBus = new JLabel("ADD/REMOVE BUS ROUTE:-");
		lblAddNewBus.setFont(new Font("Sitka Text", Font.BOLD, 20));
		lblAddNewBus.setHorizontalAlignment(SwingConstants.LEFT);
		lblAddNewBus.setBounds(20, 35, 288, 38);
		contentPane.add(lblAddNewBus);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				ASignIn asignin = new ASignIn();
				asignin.setVisible(true);
			}
		});
		btnBack.setBounds(10, 7, 73, 23);
		contentPane.add(btnBack);
		
		JLabel lblSource = new JLabel("SOURCE:");
		lblSource.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblSource.setBounds(30, 84, 100, 26);
		contentPane.add(lblSource);
		
		JComboBox comboBoxSrc = new JComboBox();
		comboBoxSrc.setModel(new DefaultComboBoxModel(new String[] {"KOLKATA", "DELHI", "CHENNAI", "AMRITSAR", "JAMMU", "ASSAM", "PURI"}));
		comboBoxSrc.setBounds(231, 84, 189, 30);
		contentPane.add(comboBoxSrc);
		
		JLabel lblDestination = new JLabel("DESTINATION:");
		lblDestination.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblDestination.setHorizontalAlignment(SwingConstants.LEFT);
		lblDestination.setBounds(30, 129, 111, 26);
		contentPane.add(lblDestination);
		
		JComboBox comboBoxDest = new JComboBox();
		comboBoxDest.setModel(new DefaultComboBoxModel(new String[] {"DELHI", "CHENNAI", "AMRITSAR", "JAMMU", "ASSAM", "PURI", "KOLKATA"}));
		comboBoxDest.setBounds(231, 125, 189, 34);
		contentPane.add(comboBoxDest);
		
		JLabel lblBusName = new JLabel("BUS NAME:");
		lblBusName.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblBusName.setHorizontalAlignment(SwingConstants.LEFT);
		lblBusName.setBounds(30, 180, 111, 23);
		contentPane.add(lblBusName);
		
		textBn = new JTextField();
		textBn.setBounds(150, 181, 108, 20);
		contentPane.add(textBn);
		textBn.setColumns(10);
		
		JLabel lblNumberOfSeats = new JLabel("AVAILABLE SEATS:");
		lblNumberOfSeats.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblNumberOfSeats.setBounds(290, 180, 162, 23);
		contentPane.add(lblNumberOfSeats);
		
		textAs = new JTextField();
		textAs.setBounds(461, 181, 100, 20);
		contentPane.add(textAs);
		textAs.setColumns(10);
		
		JLabel lblDepartureTime = new JLabel("DEPARTURE TIME:");
		lblDepartureTime.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblDepartureTime.setBounds(30, 227, 153, 26);
		contentPane.add(lblDepartureTime);
		
		textDt = new JTextField();
		textDt.setBounds(173, 230, 80, 20);
		contentPane.add(textDt);
		textDt.setColumns(10);
		
		JLabel lblArrivalTime = new JLabel("ARRIVAL TIME:");
		lblArrivalTime.setHorizontalAlignment(SwingConstants.LEFT);
		lblArrivalTime.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblArrivalTime.setBounds(274, 230, 146, 20);
		contentPane.add(lblArrivalTime);
		
		textAt = new JTextField();
		textAt.setBounds(391, 230, 86, 20);
		contentPane.add(textAt);
		textAt.setColumns(10);
		
		JLabel lblBusType = new JLabel("BUS TYPE:");
		lblBusType.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblBusType.setBounds(497, 230, 73, 20);
		contentPane.add(lblBusType);
		
		JComboBox comboBoxBt = new JComboBox();
		comboBoxBt.setModel(new DefaultComboBoxModel(new String[] {"AC", "NON-AC"}));
		comboBoxBt.setBounds(573, 230, 73, 20);
		contentPane.add(comboBoxBt);
		JLabel lblNewLabel = new JLabel("DAY:");
		lblNewLabel.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblNewLabel.setBounds(30, 264, 86, 30);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBoxDy = new JComboBox();
		comboBoxDy.setFont(new Font("Tahoma", Font.PLAIN, 13));
		comboBoxDy.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBoxDy.setBounds(89, 264, 80, 30);
		contentPane.add(comboBoxDy);
		
		JLabel lblNewLabel_1 = new JLabel("MONTH:");
		lblNewLabel_1.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(246, 264, 86, 30);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBoxMnth = new JComboBox();
		comboBoxMnth.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		comboBoxMnth.setFont(new Font("Tahoma", Font.PLAIN, 13));
		comboBoxMnth.setBounds(323, 264, 84, 31);
		contentPane.add(comboBoxMnth);
		
		JLabel lblNewLabel_2 = new JLabel("YEAR:");
		lblNewLabel_2.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(488, 267, 73, 25);
		contentPane.add(lblNewLabel_2);
		
		JComboBox comboBoxYr = new JComboBox();
		comboBoxYr.setFont(new Font("Tahoma", Font.PLAIN, 13));
		comboBoxYr.setModel(new DefaultComboBoxModel(new String[] {"2018"}));
		comboBoxYr.setBounds(551, 265, 80, 29);
		contentPane.add(comboBoxYr);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "insert into Busroute_Details (Source,Destin,BusName,AvailableSeats,DepartureTime,ArrivalTime,BusType,Dy,Mnth,Yr) values (?,?,?,?,?,?,?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, comboBoxSrc.getSelectedItem()+"");
					pst.setString(2, comboBoxDest.getSelectedItem()+"");
					pst.setString(3, textBn.getText());
					pst.setString(4, textAs.getText());
					pst.setString(5, textDt.getText());
					pst.setString(6, textAt.getText());
					pst.setString(7, comboBoxBt.getSelectedItem()+"");
					pst.setString(8, comboBoxDy.getSelectedItem()+"");
					pst.setString(9, comboBoxMnth.getSelectedItem()+"");
					pst.setString(10, comboBoxYr.getSelectedItem()+"");
									
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Bus Route Added Successfully");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnAdd.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnAdd.setBounds(78, 322, 200, 38);
		contentPane.add(btnAdd);
		
		JButton btnDisplay = new JButton("REMOVE");
		btnDisplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				Removebusroute rmvbusroute = new Removebusroute();
				rmvbusroute.setVisible(true);
			}
		});
		btnDisplay.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnDisplay.setBounds(360, 322, 200, 38);
		contentPane.add(btnDisplay);
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textBn.setText("");
				textAs.setText("");
				textDt.setText("");
				textAt.setText("");
			}
		});
		btnReset.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnReset.setBounds(215, 387, 205, 47);
		contentPane.add(btnReset);
		
		
	}
}

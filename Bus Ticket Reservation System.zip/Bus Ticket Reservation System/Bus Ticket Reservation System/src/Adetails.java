import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import java.awt.Font;
import java.sql.*;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Adetails extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textPassword;
	private JTextField textUsername;
	private JTextField textSurname;
	private JTextField textName;
	private JTextField textAID;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Adetails frame = new Adetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	public void refreshTable() {
		try {
			String query = "Select * from Admin_Details";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			pst.close();
			rs.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	private void jtableLinkDb() {
		try {
			String query = "select * from User_Details ";
			PreparedStatement pst = connection.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			//pst.close();
			//rs.close();
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	/**
	 * Create the frame.
	 */
	public Adetails() {
		connection=sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 868, 417);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JOptionPane.showMessageDialog(null, "Do not interfere with the Admin Id!!");
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				ASignIn asignin = new ASignIn();
				asignin.setVisible(true);
			}
		});
		btnBack.setBounds(10, 11, 70, 23);
		contentPane.add(btnBack);
		
		JLabel lblAdminDetails = new JLabel("ADMIN DETAILS");
		lblAdminDetails.setFont(new Font("Times New Roman", Font.BOLD, 28));
		lblAdminDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdminDetails.setBounds(286, 23, 229, 47);
		contentPane.add(lblAdminDetails);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					int row =table.getSelectedRow();
					String AID = (table.getModel().getValueAt(row, 0)+"");
					String query = "select * from Admin_Details  where AID='"+AID+"' ";
					PreparedStatement pst = connection.prepareStatement(query);
					ResultSet rs =pst.executeQuery();
					
					while(rs.next()) {
						textAID.setText(rs.getString("AID"));
						textName.setText(rs.getString("Name"));
						textSurname.setText(rs.getString("Surname"));
						textUsername.setText(rs.getString("Username"));
						textPassword.setText(rs.getString("Password"));
						}
					
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		table.setBounds(10, 66, 554, 303);
		contentPane.add(table);
		
		JLabel lblAdminId = new JLabel("Admin Id");
		lblAdminId.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		lblAdminId.setBounds(585, 81, 96, 32);
		contentPane.add(lblAdminId);
		
		JLabel label_1 = new JLabel("Name");
		label_1.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label_1.setBounds(585, 117, 100, 32);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("Surname");
		label_2.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label_2.setBounds(585, 152, 96, 32);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("Username");
		label_3.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label_3.setBounds(585, 187, 96, 32);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("Password");
		label_4.setFont(new Font("Sitka Text", Font.PLAIN, 15));
		label_4.setBounds(585, 225, 96, 32);
		contentPane.add(label_4);
		
		textPassword = new JTextField();
		textPassword.setColumns(10);
		textPassword.setBounds(695, 228, 149, 26);
		contentPane.add(textPassword);
		
		textUsername = new JTextField();
		textUsername.setColumns(10);
		textUsername.setBounds(695, 191, 149, 26);
		contentPane.add(textUsername);
		
		textSurname = new JTextField();
		textSurname.setColumns(10);
		textSurname.setBounds(695, 158, 149, 26);
		contentPane.add(textSurname);
		
		textName = new JTextField();
		textName.setColumns(10);
		textName.setBounds(695, 120, 149, 23);
		contentPane.add(textName);
		
		textAID = new JTextField();
		textAID.setColumns(10);
		textAID.setBounds(695, 86, 149, 23);
		contentPane.add(textAID);
		
		JButton btnSave = new JButton("SAVE");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String query = "insert into Admin_Details (AID,Name,Surname,Username,Password) values (?,?,?,?,?)";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textAID.getText());
					pst.setString(2, textName.getText());
					pst.setString(3, textSurname.getText());
					pst.setString(4, textUsername.getText());
					pst.setString(5, textPassword.getText());
										
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Saved");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textAID.setText("");
				textName.setText("");
				textSurname.setText("");
				textUsername.setText("");
				textPassword.setText("");
							
			}
		});
		btnSave.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnSave.setBounds(631, 268, 165, 32);
		contentPane.add(btnSave);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//JOptionPane.showMessageDialog(null, "Do not intefere with the Admin Id!!");
				try {
					String query = "Update Admin_Details set AID='"+textAID.getText()+"', Name='"+textName.getText()+"',Surname='"+textSurname.getText()+"', Username='"+textUsername.getText()+"', Password='"+textPassword.getText()+"' where AID='"+textAID.getText()+"'";
					PreparedStatement pst = connection.prepareStatement(query);
				
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Updated");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textAID.setText("");
				textName.setText("");
				textSurname.setText("");
				textUsername.setText("");
				textPassword.setText("");
			}
		});
		btnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnUpdate.setBounds(631, 301, 165, 32);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE ACCOUNT");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int action = JOptionPane.showConfirmDialog(null,"Do you really want to Delete","Delete",JOptionPane.YES_NO_OPTION);
				if(action==0) {
				try {
					String query = "delete from Admin_Details where AID='"+textAID.getText()+"'";
					PreparedStatement pst = connection.prepareStatement(query);
				
					pst.execute();
					
					JOptionPane.showMessageDialog(null, "Data Deleted");
					
					pst.close();
					
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				refreshTable();
				textAID.setText("");
				textName.setText("");
				textSurname.setText("");
				textUsername.setText("");
				textPassword.setText("");
				}
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnDelete.setBounds(631, 334, 165, 32);
		contentPane.add(btnDelete);
		
		jtableLinkDb();
		refreshTable();
	}

}

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Ulogin extends JFrame {

	private static final String WindowEvent = null;
	private JPanel contentPane;
	private JTextField textUsername;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ulogin frame = new Ulogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection = null;
	private JPasswordField passwordField;
	
	
	/**
	 * Create the frame.
	 */
	public Ulogin() {
		connection=sqliteConnection.dbConnector();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 641, 409);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserLogin = new JLabel("USER LOGIN");
		lblUserLogin.setFont(new Font("Sitka Text", Font.BOLD, 23));
		lblUserLogin.setHorizontalAlignment(SwingConstants.CENTER);
		lblUserLogin.setBounds(244, 35, 144, 40);
		contentPane.add(lblUserLogin);
		
		JLabel lblUsername = new JLabel("USERNAME");
		lblUsername.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblUsername.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsername.setBounds(169, 101, 110, 32);
		contentPane.add(lblUsername);
		
		textUsername = new JTextField();
		textUsername.setBounds(337, 101, 137, 31);
		contentPane.add(textUsername);
		textUsername.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("PASSWORD");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(169, 155, 110, 31);
		contentPane.add(lblNewLabel);
		
		JButton btnSign = new JButton("LOG IN");
		btnSign.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnSign.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query = "select * from User_Details where username = ? and password = ?";
					PreparedStatement pst = connection.prepareStatement(query);
					pst.setString(1, textUsername.getText());
					pst.setString(2, passwordField.getText());
					
					ResultSet rs = pst.executeQuery();
					int count=0;
					while(rs.next()) {
						count++;
					}
					if(count==1) {
						JOptionPane.showMessageDialog(null, "Login Successfully");
						dispose();
						USignIn usignin = new USignIn();
						usignin.setVisible(true);
					}
					else if(count > 1) {
						JOptionPane.showMessageDialog(null, "Duplicate Username and Password");
					}
					else {
						JOptionPane.showMessageDialog(null, "Username and Password is not correct Try Again....");
					}
					rs.close();
					pst.close();
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e);
				}
			}
		});
		btnSign.setBounds(194, 228, 99, 31);
		contentPane.add(btnSign);
		
		JButton btnSignUp = new JButton("REGISTER");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Uregister uregister = new Uregister();
				uregister.setVisible(true);
			}
		});
		btnSignUp.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnSignUp.setBounds(353, 228, 99, 31);
		contentPane.add(btnSignUp);
		
		JButton btnForgotPassword = new JButton("RESET");
		btnForgotPassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textUsername.setText("");
				passwordField.setText("");
			}
		});
		btnForgotPassword.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnForgotPassword.setBounds(266, 291, 110, 32);
		contentPane.add(btnForgotPassword);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Welcome wlcm = new Welcome();
			    wlcm.frame.setVisible(true);
			}
			
		});
		btnBack.setBounds(10, 11, 67, 23);
		contentPane.add(btnBack);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(337, 155, 137, 31);
		contentPane.add(passwordField);
	}
}
